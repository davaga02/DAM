package com.dam.daniela;

public class App {
	
	
	public static  String sayHello() {
		
		return "Hola Mundo";
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(sayHello());
		

	}

}
