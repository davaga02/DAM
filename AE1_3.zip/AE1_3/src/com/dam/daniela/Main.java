package com.dam.daniela;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void nombresYEnteros () {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		ArrayList <Integer> enteros = new ArrayList<Integer> ();
		
		String[] nombres = new String[5];
		nombres[0] = "Pablo";
		nombres[1] = "Quique";
		nombres[2] = "Carles";
		nombres[3] = "Alberto";
		nombres[4] = "Gonzalo";
		nombres[5] = "Daniela";
		
		System.out.println("Dame numeros enteros");
		
		do {
			
			int numero = teclado.nextInt();
			enteros.add(numero);
			
		}while(true);
			
			
		
		
		
		
		}

	}


