package com.dam.daniela;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int cont = 0;
		int suma = 0;
		
		System.out.println("Dime 2 numeros como extremos de intervalos");
		System.out.println("Dime el numero mas pequeño: ");
		int numPequenyo = teclado.nextInt();
		System.out.println("Dime el numero mas grande: ");
		int numGrande = teclado.nextInt();
		
		if (numPequenyo < numGrande) {
			
			for(int i = numPequenyo; i <= numGrande; i++) {
				
				cont++;
				if(i % cont == 0) {
					
					System.out.println(i + " es primo");
						
					}else{
						System.out.println(i + " no es primo");
					}
					
				suma = suma + i;
			}
			
			System.out.println(suma);
			
		}else if(numPequenyo > numGrande || numPequenyo == numGrande) {
			
			System.out.println("Error un numero tiene que ser menor que el otro");
		}

	}

}
